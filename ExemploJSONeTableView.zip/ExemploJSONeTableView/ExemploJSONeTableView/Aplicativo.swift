//
//  Aplicativo.swift
//  ExemploJSONeTableView
//
//  Created by Usuário Convidado on 17/09/2018.
//  Copyright © 2018 Gabriela Gomes. All rights reserved.
//

import UIKit

class Aplicativo: NSObject {
    var nome:String = ""
    var imagemSTR:String = ""
    var imagem:UIImage? = nil
}
